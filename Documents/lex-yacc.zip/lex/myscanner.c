#include <stdio.h>
#include "defs.h"

extern int yylex(); // gets token id
extern int yylineno; // has token line number
extern char* yytext; // has token value

int main(void) 
{
	// print all tokens
	// int token;
	// token = yylex();
	// while (token){
	// 	printf("%d %d\n", token,yylineno);
	// 	token = yylex();
	// }

	// print count of integers
	// int token;
	// int count = 0;
	// token = yylex();
	// while (token){
	// 	if (token == T_RAQM) count++;
	// 	token = yylex();
	// }
	// printf("%d integers found in input program\n",count);

	// check for syntax error
	int token;
	token = yylex();
	while (token){
		if (token != T_RAQM && token != T_NUS){
			printf("Expected a type at line %d but found %s\n",yylineno,yytext);
			return 1;
		}

		token = yylex();
		if (token != IDENTIFIER){
			printf("Expected an identifier at line %d but found %s\n",yylineno,yytext);
			return 1;
		}
		
		if (yylex() != EQUAL){
			printf("Expected a '=' at line %d but found %s\n",yylineno,yytext);
			return 1;
		}
			
		token = yylex();
		if (token != INTEGER && token != STRING){
			printf("Expected a value at line %d but found %s\n",yylineno,yytext);
			return 1;
		}

		token = yylex();
	}
	printf("Done!\n");
	return 0;
}