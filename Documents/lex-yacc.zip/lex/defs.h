#define T_RAQM 1
#define T_NUS 2
#define EQUAL 3
#define IDENTIFIER 4
#define INTEGER 5
#define STRING 6